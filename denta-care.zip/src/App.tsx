/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Header from './components/Header';
import Hero from './components/Hero';
import HeroStats from './components/HeroStats';
import Marquee from './components/Marquee';
import About from './components/About';
import Treatments from './components/Treatments';
import FeaturedTreatment from './components/FeaturedTreatment';
import WhyChooseUs from './components/WhyChooseUs';
import Technology from './components/Technology';
import ClinicEnvironment from './components/ClinicEnvironment';
import PatientExperience from './components/PatientExperience';
import Testimonials from './components/Testimonials';
import Appointment from './components/Appointment';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 selection:bg-[#20B8F2] selection:text-white">
      <Header />
      <main>
        <Hero />
        <HeroStats />
        <Marquee />
        <About />
        <Treatments />
        <FeaturedTreatment />
        <WhyChooseUs />
        <Technology />
        <ClinicEnvironment />
        <PatientExperience />
        <Testimonials />
        <Appointment />
      </main>
      <Footer />
    </div>
  );
}
