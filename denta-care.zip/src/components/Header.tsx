import { motion } from 'motion/react';
import { Menu, ArrowUpRight } from 'lucide-react';

export default function Header() {
  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-6 py-4 mx-4 mt-4 bg-white/90 backdrop-blur-md rounded-2xl shadow-[0_2px_10px_rgba(0,0,0,0.03)] border border-gray-100/50 max-w-7xl xl:mx-auto"
    >
      <div className="flex flex-col leading-none">
        <span className="text-xl font-bold tracking-tight text-slate-900 font-heading">DENTA</span>
        <span className="text-xl font-bold tracking-tight text-[#20B8F2] font-heading">CARE</span>
      </div>

      <nav className="hidden md:flex items-center gap-8">
        {['Home', 'About', 'Treatments', 'Technology', 'Our Clinic', 'FAQs', 'Contact'].map((item) => (
          <a 
            key={item} 
            href={`#${item.toLowerCase().replace(' ', '-')}`}
            className="text-sm font-medium text-slate-600 hover:text-[#0077C8] transition-colors relative group"
          >
            {item}
            <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#20B8F2] transition-all group-hover:w-full"></span>
          </a>
        ))}
      </nav>

      <div className="flex items-center gap-4">
        <a 
          href="#appointment"
          className="hidden md:flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white transition-all bg-[#FF4B12] rounded-full hover:bg-[#e03d0a] hover:-translate-y-0.5 hover:shadow-lg hover:shadow-[#FF4B12]/20"
        >
          BOOK APPOINTMENT
          <ArrowUpRight className="w-4 h-4" />
        </a>
        <button className="p-2 text-slate-900 md:hidden hover:bg-slate-50 rounded-full transition-colors">
          <Menu className="w-6 h-6" />
        </button>
      </div>
    </motion.header>
  );
}
