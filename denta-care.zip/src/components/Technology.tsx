import { motion } from 'motion/react';

export default function Technology() {
  return (
    <section className="py-24 px-4 bg-[#111111]" id="technology">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-5xl md:text-7xl font-bold font-heading leading-[1.1] text-white"
          >
            MODERN DENTISTRY.<br/>
            <span className="text-[#20B8F2]">ADVANCED TECHNOLOGY.</span>
          </motion.h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 h-auto lg:h-[600px]">
          {/* Main Visual */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-[#1A1A1A] rounded-[2rem] border border-white/10 p-8 relative overflow-hidden flex flex-col justify-end min-h-[400px]"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent z-10"></div>
            
            {/* Abstract Tech Graphic: Wireframe Tooth / Scanner UI */}
            <div className="absolute inset-0 flex items-center justify-center opacity-40">
              <svg viewBox="0 0 200 200" className="w-full h-full max-w-sm">
                 <path d="M50 100 Q 100 20, 150 100 T 150 180 Q 100 150, 50 180 Z" fill="none" stroke="#20B8F2" strokeWidth="2" strokeDasharray="4 4" />
                 <path d="M60 100 Q 100 40, 140 100 T 140 160 Q 100 140, 60 160 Z" fill="none" stroke="#BDEFFF" strokeWidth="1" />
                 <circle cx="100" cy="100" r="40" fill="none" stroke="#FF4B12" strokeWidth="1" opacity="0.5" />
                 <line x1="0" y1="100" x2="200" y2="100" stroke="#0077C8" strokeWidth="1" opacity="0.5" />
                 <line x1="100" y1="0" x2="100" y2="200" stroke="#0077C8" strokeWidth="1" opacity="0.5" />
              </svg>
            </div>

            <div className="relative z-20 max-w-md">
              <div className="inline-flex px-3 py-1 mb-4 text-xs font-bold tracking-wider text-[#20B8F2] uppercase bg-[#20B8F2]/10 border border-[#20B8F2]/20 rounded-full">
                Digital Workflow
              </div>
              <h3 className="text-3xl font-bold font-heading text-white mb-3">CAD/CAM Dentistry</h3>
              <p className="text-gray-400 font-medium">Single-visit ceramic restorations designed and milled precisely in our clinic.</p>
            </div>
          </motion.div>

          <div className="grid grid-rows-2 gap-8">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-[#1A1A1A] rounded-[2rem] border border-white/10 p-8 flex flex-col sm:flex-row items-center gap-8 relative overflow-hidden"
            >
              <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-2xl bg-[#0077C8]/20 flex items-center justify-center shrink-0 border border-[#0077C8]/30">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#20B8F2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
              </div>
              <div>
                <h3 className="text-2xl font-bold font-heading text-white mb-2">3D Intraoral Scanning</h3>
                <p className="text-gray-400 font-medium text-sm leading-relaxed">No more messy impressions. We capture highly accurate digital 3D models of your teeth in seconds.</p>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-[#1A1A1A] rounded-[2rem] border border-white/10 p-8 flex flex-col sm:flex-row items-center gap-8 relative overflow-hidden"
            >
              <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-2xl bg-[#FF4B12]/10 flex items-center justify-center shrink-0 border border-[#FF4B12]/20">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#FF4B12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
              </div>
              <div>
                <h3 className="text-2xl font-bold font-heading text-white mb-2">Digital Smile Design</h3>
                <p className="text-gray-400 font-medium text-sm leading-relaxed">Preview your final result before treatment begins using advanced facial and dental analysis software.</p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
