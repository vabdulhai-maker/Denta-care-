import { motion } from 'motion/react';

export default function PatientExperience() {
  const steps = [
    { num: "01", title: "BOOK", desc: "Choose a convenient appointment time." },
    { num: "02", title: "MEET", desc: "Discuss your dental needs." },
    { num: "03", title: "PLAN", desc: "Receive a personalized treatment plan." },
    { num: "04", title: "SMILE", desc: "Move toward healthier teeth and better confidence." }
  ];

  return (
    <section className="py-24 px-4 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-5xl md:text-7xl font-bold font-heading leading-[1.1] text-slate-900"
          >
            THE JOURNEY.
          </motion.h2>
        </div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gradient-to-r from-[#DDF6FF] via-[#20B8F2] to-[#0077C8] -translate-y-1/2 hidden md:block"></div>

          <div className="grid md:grid-cols-4 gap-12 md:gap-8 relative z-10">
            {steps.map((step, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="flex flex-col items-center text-center bg-white"
              >
                <div className="w-16 h-16 bg-white border-4 border-[#F5F7F8] rounded-full flex items-center justify-center text-xl font-bold font-heading text-[#0077C8] mb-8 shadow-[0_0_20px_rgba(32,184,242,0.2)]">
                  {step.num}
                </div>
                <h3 className="text-2xl font-bold font-heading text-slate-900 mb-3">{step.title}</h3>
                <p className="text-slate-500 font-medium max-w-[200px]">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
