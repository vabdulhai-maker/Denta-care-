import { motion } from 'motion/react';
import { ArrowUpRight, ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative pt-32 pb-16 md:pt-48 md:pb-32 px-4 overflow-hidden max-w-[1440px] mx-auto" id="home">
      <div className="absolute inset-0 -z-10 bg-[#F5F7F8] rounded-[2rem] md:rounded-[3rem] mx-2 md:mx-6 mt-2 md:mt-6 overflow-hidden">
        {/* Abstract background graphics since we cannot use human photos */}
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-bl from-[#DDF6FF] to-transparent rounded-full blur-3xl opacity-60 translate-x-1/3 -translate-y-1/3"></div>
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-gradient-to-tr from-[#BDEFFF] to-transparent rounded-full blur-3xl opacity-40 -translate-x-1/3 translate-y-1/3"></div>
      </div>

      <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center max-w-7xl mx-auto">
        <div className="lg:col-span-7 flex flex-col items-start px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 mb-6 text-xs font-bold tracking-wider text-[#0077C8] uppercase bg-white border border-[#BDEFFF] rounded-full"
          >
            <span className="w-2 h-2 rounded-full bg-[#20B8F2] animate-pulse"></span>
            Modern Dental Care
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="text-6xl md:text-8xl lg:text-[7rem] font-bold font-heading leading-[0.9] tracking-tight text-slate-900 mb-8"
          >
            EVERY<br/>
            <span className="text-[#0077C8]">SMILE</span><br/>
            MATTERS.
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-lg md:text-xl text-slate-600 mb-10 max-w-xl font-medium leading-relaxed"
          >
            Advanced dentistry designed around your comfort, confidence, and long-term oral health.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto"
          >
            <a 
              href="#appointment"
              className="flex items-center justify-center w-full sm:w-auto gap-2 px-8 py-4 text-sm font-semibold text-white transition-all bg-[#FF4B12] rounded-full hover:bg-[#e03d0a] hover:-translate-y-1 hover:shadow-xl hover:shadow-[#FF4B12]/20"
            >
              BOOK APPOINTMENT
              <ArrowUpRight className="w-4 h-4" />
            </a>
            <a 
              href="#treatments"
              className="flex items-center justify-center w-full sm:w-auto gap-2 px-8 py-4 text-sm font-semibold transition-all bg-white text-slate-900 rounded-full hover:bg-slate-50 hover:-translate-y-1 hover:shadow-lg border border-gray-200"
            >
              EXPLORE TREATMENTS
              <ArrowRight className="w-4 h-4" />
            </a>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="mt-12 flex items-center gap-4 px-6 py-4 bg-white/60 backdrop-blur-sm rounded-2xl border border-white/40 shadow-sm"
          >
            <div className="w-12 h-12 rounded-full bg-[#DDF6FF] flex items-center justify-center text-[#0077C8]">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
            <div>
              <div className="text-xs font-bold tracking-wider text-slate-500 uppercase">Open Today</div>
              <div className="text-sm font-semibold text-slate-900">10:00 AM – 07:00 PM</div>
            </div>
          </motion.div>
        </div>

        <div className="lg:col-span-5 relative flex justify-center items-center h-[500px] lg:h-[700px]">
          {/* Abstract Dental Hero Graphic since we have no generated images */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full h-full max-w-md mx-auto"
          >
            {/* Base geometric shape representing clinical precision */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#20B8F2]/10 to-[#0077C8]/20 rounded-[3rem] rotate-3 shadow-[inset_0_0_100px_rgba(255,255,255,0.8)] backdrop-blur-xl border border-white/50"></div>
            <div className="absolute inset-0 bg-white rounded-[3rem] -rotate-3 shadow-2xl overflow-hidden flex items-center justify-center p-8">
              {/* Abstract Tooth Representation */}
              <div className="relative w-full h-full flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-48 h-48 md:w-64 md:h-64 text-[#20B8F2] opacity-20 absolute drop-shadow-2xl">
                   <path fill="currentColor" d="M30 20 C 30 10, 70 10, 70 20 C 70 40, 90 60, 80 80 C 70 100, 50 80, 50 80 C 50 80, 30 100, 20 80 C 10 60, 30 40, 30 20 Z" />
                </svg>
                <div className="relative z-10 grid grid-cols-2 gap-4 w-full aspect-square p-4">
                  <div className="bg-[#DDF6FF] rounded-tl-[40px] rounded-tr-[10px] rounded-br-[10px] rounded-bl-[10px]"></div>
                  <div className="bg-[#0077C8] rounded-tr-[40px] rounded-tl-[10px] rounded-br-[10px] rounded-bl-[10px]"></div>
                  <div className="bg-[#20B8F2] rounded-bl-[40px] rounded-tl-[10px] rounded-tr-[10px] rounded-br-[10px]"></div>
                  <div className="bg-[#BDEFFF] rounded-br-[40px] rounded-tl-[10px] rounded-tr-[10px] rounded-bl-[10px]"></div>
                </div>
              </div>
            </div>

            {/* Floating Elements */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute top-10 -left-10 px-4 py-3 bg-white rounded-2xl shadow-xl border border-gray-100 flex items-center gap-3"
            >
              <div className="w-8 h-8 rounded-full bg-[#DDF6FF] flex items-center justify-center text-[#0077C8]">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              </div>
              <span className="text-sm font-bold text-slate-800">Pain-Conscious Care</span>
            </motion.div>

            <motion.div 
              animate={{ y: [0, 15, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute bottom-20 -right-12 px-4 py-3 bg-white rounded-2xl shadow-xl border border-gray-100 flex items-center gap-3"
            >
              <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
              </div>
              <span className="text-sm font-bold text-slate-800">Advanced Tech</span>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
