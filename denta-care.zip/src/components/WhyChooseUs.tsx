import { motion } from 'motion/react';
import { Microchip, ShieldCheck, Heart, Sparkles } from 'lucide-react';

export default function WhyChooseUs() {
  const reasons = [
    { num: "01", title: "Advanced Technology", desc: "We utilize state-of-the-art digital scanners and 3D imaging for precise diagnostics and treatment planning.", icon: Microchip },
    { num: "02", title: "Experienced Care", desc: "Our specialists bring decades of combined clinical excellence in complex dental procedures.", icon: ShieldCheck },
    { num: "03", title: "Personalized Treatment", desc: "Every smile is unique. We craft bespoke treatment plans tailored to your specific goals and biology.", icon: Sparkles },
    { num: "04", title: "Comfort-First", desc: "Designed to minimize anxiety, our clinic environment and gentle techniques prioritize your peace of mind.", icon: Heart },
  ];

  return (
    <section className="py-24 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-5xl md:text-7xl font-bold font-heading leading-[1.1] text-slate-900 mb-16 text-center"
        >
          WHY<br/>
          <span className="text-[#0077C8]">DENTA CARE?</span>
        </motion.h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, idx) => {
            const Icon = reason.icon;
            return (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="flex flex-col group p-8 rounded-3xl bg-[#F5F7F8] hover:bg-white border border-transparent hover:border-gray-100 hover:shadow-2xl transition-all duration-500"
              >
                <div className="flex justify-between items-start mb-12">
                  <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center text-[#20B8F2] group-hover:scale-110 group-hover:bg-[#0077C8] group-hover:text-white transition-all duration-500">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-4xl font-bold font-heading text-gray-200 group-hover:text-[#FF4B12]/20 transition-colors">{reason.num}</span>
                </div>
                <h3 className="text-2xl font-bold font-heading text-slate-900 mb-4">{reason.title}</h3>
                <p className="text-slate-500 font-medium leading-relaxed">{reason.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
