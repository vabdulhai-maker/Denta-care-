import { motion } from 'motion/react';

export default function Marquee() {
  const items = [
    "GENERAL DENTISTRY",
    "COSMETIC DENTISTRY",
    "ORTHODONTICS",
    "DENTAL IMPLANTS",
    "TEETH WHITENING",
    "PREVENTIVE CARE"
  ];

  return (
    <section className="py-16 md:py-24 overflow-hidden bg-white flex items-center">
      <div className="flex w-[200%] md:w-[150%]">
        <motion.div 
          animate={{ x: [0, "-50%"] }}
          transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
          className="flex items-center whitespace-nowrap"
        >
          {[...items, ...items, ...items].map((item, idx) => (
            <div key={idx} className="flex items-center">
              <span className="text-4xl md:text-6xl font-bold font-heading text-slate-100 uppercase mx-8 hover:text-[#0077C8] transition-colors duration-500 cursor-default">
                {item}
              </span>
              <span className="text-2xl text-[#20B8F2] font-light">+</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
