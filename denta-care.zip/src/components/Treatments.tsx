import { motion } from 'motion/react';
import { ArrowUpRight, CheckCircle2 } from 'lucide-react';

export default function Treatments() {
  const treatments = [
    { num: "01", name: "General Dentistry", desc: "Comprehensive exams, cleanings, and preventative care for long-term oral health." },
    { num: "02", name: "Dental Implants", desc: "Permanent, natural-looking replacements for missing teeth using titanium fixtures." },
    { num: "03", name: "Cosmetic Dentistry", desc: "Veneers, bonding, and aesthetic contouring to achieve your perfect smile." },
    { num: "04", name: "Teeth Whitening", desc: "Professional, safe whitening treatments for dramatically brighter teeth." },
    { num: "05", name: "Orthodontics", desc: "Traditional and modern alignment solutions for all ages." },
    { num: "06", name: "Clear Aligners", desc: "Virtually invisible, comfortable aligners for predictable tooth movement." },
    { num: "07", name: "Dental Crowns", desc: "Custom-crafted ceramic crowns to restore damaged or decayed teeth." },
    { num: "08", name: "Veneers", desc: "Ultra-thin porcelain shells for a complete aesthetic transformation." },
    { num: "09", name: "Root Canal", desc: "Pain-free endodontic therapy to save infected or deeply decayed teeth." },
    { num: "10", name: "Preventive Care", desc: "Sealants, fluoride treatments, and personalized hygiene plans." },
  ];

  return (
    <section className="py-24 px-4 bg-slate-50" id="treatments">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <div>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-5xl md:text-7xl font-bold font-heading leading-[1.1] text-slate-900"
            >
              ADVANCED<br/>
              TREATMENTS.
            </motion.h2>
          </div>
          <motion.a 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            href="#appointment"
            className="flex items-center gap-2 text-[#0077C8] font-bold hover:text-[#20B8F2] transition-colors"
          >
            VIEW ALL TREATMENTS <ArrowUpRight className="w-5 h-5" />
          </motion.a>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {treatments.map((treatment, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.05 }}
              className="bg-white p-6 rounded-2xl border border-gray-100 hover:shadow-xl hover:shadow-[#0077C8]/5 transition-all group flex flex-col h-full"
            >
              <div className="flex items-start justify-between mb-8">
                <span className="text-sm font-bold text-[#20B8F2]">{treatment.num}</span>
                <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-[#0077C8] group-hover:text-white transition-colors text-slate-400">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-auto">
                <h3 className="text-xl font-bold font-heading text-slate-900 mb-3">{treatment.name}</h3>
                <p className="text-sm text-slate-500 font-medium leading-relaxed">{treatment.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
