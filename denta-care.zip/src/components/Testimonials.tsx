import { motion } from 'motion/react';
import { Star } from 'lucide-react';

export default function Testimonials() {
  const reviews = [
    { text: "Exceptional experience from start to finish. Everything was explained clearly and the clinic felt incredibly comfortable.", initials: "AM" },
    { text: "Professional, modern and genuinely caring dental service. The technology they use is impressive and makes a big difference.", initials: "RK" },
    { text: "I've always been anxious about dentists, but the team here completely changed my perspective. Highly recommended.", initials: "JS" },
  ];

  return (
    <section className="py-24 px-4 bg-[#F5F7F8]">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold font-heading text-slate-900 mb-4">Patient Stories</h2>
          <div className="flex items-center justify-center gap-1 text-[#FF4B12]">
            {[1,2,3,4,5].map(i => <Star key={i} className="w-5 h-5 fill-current" />)}
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {reviews.map((review, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col justify-between"
            >
              <p className="text-lg text-slate-700 font-medium leading-relaxed italic mb-8">"{review.text}"</p>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-[#DDF6FF] flex items-center justify-center text-sm font-bold text-[#0077C8]">
                  {review.initials}
                </div>
                <div className="text-sm font-bold text-slate-900">Verified Patient</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
