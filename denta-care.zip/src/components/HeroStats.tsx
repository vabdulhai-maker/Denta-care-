import { motion } from 'motion/react';

export default function HeroStats() {
  const stats = [
    { value: "15+", label: "Years of Expertise" },
    { value: "10K+", label: "Patients Treated" },
    { value: "25+", label: "Dental Procedures" },
    { value: "98%", label: "Patient Satisfaction" }
  ];

  return (
    <section className="py-12 bg-white relative z-10 -mt-12 mx-4 md:mx-12 rounded-[2rem] shadow-2xl border border-gray-100 max-w-6xl xl:mx-auto">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 px-8">
        {stats.map((stat, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: idx * 0.1 }}
            className="flex flex-col items-center justify-center text-center border-r last:border-r-0 border-gray-100"
          >
            <div className="text-4xl md:text-5xl font-bold font-heading text-[#FF4B12] mb-2">{stat.value}</div>
            <div className="text-xs md:text-sm font-semibold tracking-wider text-slate-500 uppercase">{stat.label}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
