import { motion } from 'motion/react';

export default function ClinicEnvironment() {
  return (
    <section className="py-24 px-4 bg-slate-50" id="our-clinic">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-8">
          <div>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-5xl md:text-7xl font-bold font-heading leading-[1.1] text-slate-900"
            >
              CLINICAL<br/>
              EXCELLENCE.
            </motion.h2>
          </div>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-lg text-slate-600 font-medium max-w-sm"
          >
            A sterile, modern, and meticulously designed environment built for your peace of mind.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Mocking high-end architectural photos with CSS gradients/shapes since no human images allowed */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="md:col-span-2 h-[400px] bg-white rounded-3xl overflow-hidden relative shadow-sm border border-gray-100 group"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-[#F5F7F8] to-[#DDF6FF] flex items-center justify-center">
               {/* Abstract Treatment Room representation */}
               <div className="w-1/2 h-1/2 border-l-2 border-b-2 border-[#20B8F2]/30 relative">
                 <div className="absolute top-0 right-0 w-16 h-16 bg-white rounded-full shadow-lg border border-gray-100 flex items-center justify-center">
                    <div className="w-8 h-8 rounded-full border-4 border-[#0077C8]"></div>
                 </div>
               </div>
            </div>
            <div className="absolute bottom-6 left-6 px-4 py-2 bg-white/80 backdrop-blur-md rounded-full text-sm font-bold text-slate-900 shadow-sm">
              Treatment Suite
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="h-[400px] bg-white rounded-3xl overflow-hidden relative shadow-sm border border-gray-100"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-slate-200 to-white flex items-center justify-center">
              <svg width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="#CBD5E1" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
            </div>
             <div className="absolute bottom-6 left-6 px-4 py-2 bg-white/80 backdrop-blur-md rounded-full text-sm font-bold text-slate-900 shadow-sm">
              Sterilization Lab
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="h-[300px] bg-white rounded-3xl overflow-hidden relative shadow-sm border border-gray-100"
          >
             <div className="absolute inset-0 bg-[#0077C8] flex items-center justify-center">
               <div className="w-32 h-32 rounded-full border border-white/20 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-white/10"></div>
               </div>
            </div>
             <div className="absolute bottom-6 left-6 px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-sm font-bold text-white shadow-sm border border-white/10">
              Advanced Optics
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="md:col-span-2 h-[300px] bg-white rounded-3xl overflow-hidden relative shadow-sm border border-gray-100"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-[#F5F7F8] to-white flex items-center justify-center">
               <div className="grid grid-cols-5 gap-2 opacity-20">
                 {Array.from({length: 15}).map((_, i) => (
                    <div key={i} className="w-8 h-8 rounded-sm bg-[#20B8F2]"></div>
                 ))}
               </div>
            </div>
             <div className="absolute bottom-6 left-6 px-4 py-2 bg-white/80 backdrop-blur-md rounded-full text-sm font-bold text-slate-900 shadow-sm">
              Consultation Lounge
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
