export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white pt-24 pb-8 px-4" id="contact">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 border-b border-white/10 pb-16 mb-8">
          <div>
            <div className="flex flex-col leading-none mb-6">
              <span className="text-3xl font-bold tracking-tight text-white font-heading">DENTA</span>
              <span className="text-3xl font-bold tracking-tight text-[#20B8F2] font-heading">CARE</span>
            </div>
            <p className="text-gray-400 text-sm font-medium leading-relaxed max-w-xs">
              Advanced dental care with a premium, modern experience.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-bold tracking-wider uppercase text-white mb-6">Navigation</h4>
            <ul className="space-y-4 text-gray-400 font-medium">
              <li><a href="#home" className="hover:text-[#20B8F2] transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-[#20B8F2] transition-colors">About</a></li>
              <li><a href="#treatments" className="hover:text-[#20B8F2] transition-colors">Treatments</a></li>
              <li><a href="#technology" className="hover:text-[#20B8F2] transition-colors">Technology</a></li>
              <li><a href="#our-clinic" className="hover:text-[#20B8F2] transition-colors">Our Clinic</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold tracking-wider uppercase text-white mb-6">Services</h4>
            <ul className="space-y-4 text-gray-400 font-medium">
              <li><a href="#treatments" className="hover:text-[#20B8F2] transition-colors">General Dentistry</a></li>
              <li><a href="#treatments" className="hover:text-[#20B8F2] transition-colors">Dental Implants</a></li>
              <li><a href="#treatments" className="hover:text-[#20B8F2] transition-colors">Orthodontics</a></li>
              <li><a href="#treatments" className="hover:text-[#20B8F2] transition-colors">Cosmetic Dentistry</a></li>
              <li><a href="#treatments" className="hover:text-[#20B8F2] transition-colors">Teeth Whitening</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-bold tracking-wider uppercase text-white mb-6">Contact</h4>
            <ul className="space-y-4 text-gray-400 font-medium">
              <li>+1 (555) 123-4567</li>
              <li>hello@dentacare.com</li>
              <li>123 Premium Medical Plaza<br/>Suite 400, New York, NY</li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between text-sm text-gray-500 font-medium">
          <div>© {new Date().getFullYear()} Denta Care. All rights reserved.</div>
          <div className="flex items-center gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms & Conditions</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
