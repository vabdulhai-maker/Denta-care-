import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';

export default function FeaturedTreatment() {
  return (
    <section className="py-8 px-4 max-w-7xl mx-auto">
      <div className="bg-[#0077C8] rounded-[2rem] md:rounded-[3rem] p-8 md:p-16 lg:p-24 overflow-hidden relative flex flex-col lg:flex-row items-center gap-12">
        {/* Dynamic Abstract Background representing technology/alignment */}
        <div className="absolute inset-0 opacity-20">
           <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-[#20B8F2] rounded-full blur-[120px] opacity-50 translate-x-1/3 -translate-y-1/3"></div>

        <div className="relative z-10 lg:w-1/2">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex px-4 py-2 mb-8 text-xs font-bold tracking-wider text-white uppercase bg-white/10 rounded-full backdrop-blur-md border border-white/20"
          >
            FLAGSHIP SERVICE
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl font-bold font-heading leading-[0.9] text-white mb-8"
          >
            SMILE<br/>
            ALIGNMENT.
          </motion.h2>
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-2xl font-semibold text-[#BDEFFF] mb-4 font-heading"
          >
            PRECISION ORTHODONTICS
          </motion.h3>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-lg text-white/80 mb-10 max-w-md font-medium leading-relaxed"
          >
            Modern alignment solutions designed for comfort, aesthetics and predictable results using advanced 3D scanning.
          </motion.p>
          <motion.a 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            href="#treatments"
            className="inline-flex items-center gap-2 px-8 py-4 text-sm font-semibold text-slate-900 transition-all bg-white rounded-full hover:bg-slate-100 hover:shadow-xl"
          >
            EXPLORE ORTHODONTICS
            <ArrowUpRight className="w-4 h-4" />
          </motion.a>
        </div>

        <div className="relative z-10 lg:w-1/2 w-full flex justify-center items-center h-[300px] md:h-[400px]">
          {/* Abstract visualization of a clear aligner/dental arch */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="relative w-full max-w-sm aspect-square"
          >
            {/* Base arch */}
            <svg viewBox="0 0 200 200" className="w-full h-full drop-shadow-2xl">
              <path d="M 20 150 C 20 50, 180 50, 180 150" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="30" strokeLinecap="round" />
              <path d="M 20 150 C 20 50, 180 50, 180 150" fill="none" stroke="rgba(255,255,255,0.9)" strokeWidth="10" strokeLinecap="round" />
              {/* Tech overlay nodes */}
              <circle cx="20" cy="150" r="8" fill="#FF4B12" />
              <circle cx="50" cy="90" r="6" fill="#20B8F2" />
              <circle cx="100" cy="65" r="8" fill="#20B8F2" />
              <circle cx="150" cy="90" r="6" fill="#20B8F2" />
              <circle cx="180" cy="150" r="8" fill="#FF4B12" />
              
              {/* Scanning laser line */}
              <motion.line 
                x1="0" y1="100" x2="200" y2="100" 
                stroke="#FF4B12" strokeWidth="2"
                animate={{ y1: [40, 170, 40], y2: [40, 170, 40] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                opacity="0.5"
              />
            </svg>
            <div className="absolute inset-0 bg-gradient-to-t from-[#0077C8] via-transparent to-transparent opacity-50 pointer-events-none"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
