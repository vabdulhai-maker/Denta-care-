import { motion } from 'motion/react';
import { Shield, Sparkles, Activity, Layers } from 'lucide-react';

export default function About() {
  return (
    <section className="py-24 px-4 max-w-7xl mx-auto" id="about">
      <div className="grid lg:grid-cols-2 gap-16 items-start">
        <div className="flex flex-col">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex px-3 py-1 mb-6 text-xs font-bold tracking-wider text-[#FF4B12] uppercase bg-[#FF4B12]/10 rounded-full self-start"
          >
            OUR APPROACH
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl md:text-7xl font-bold font-heading leading-[1.1] text-slate-900 mb-8"
          >
            DENTISTRY,<br/>
            RETHOUGHT.
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-slate-600 font-medium leading-relaxed max-w-md"
          >
            We combine advanced dental technology with personalized care to create healthier, more confident smiles in a calm and welcoming environment.
          </motion.p>
        </div>

        <div className="relative">
          {/* Abstract Editorial Collage of Dental Elements */}
          <div className="grid grid-cols-2 gap-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-[#F5F7F8] rounded-[2rem] aspect-square flex flex-col justify-between p-8 relative overflow-hidden group"
            >
              <Shield className="w-10 h-10 text-[#0077C8]" />
              <div className="text-xl font-bold text-slate-900 font-heading">Sterile<br/>Environment</div>
              <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-[#DDF6FF] rounded-full blur-2xl opacity-50 group-hover:bg-[#20B8F2]/30 transition-colors"></div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-[#0077C8] rounded-[2rem] aspect-square flex flex-col justify-between p-8 text-white relative overflow-hidden"
            >
              <Activity className="w-10 h-10 text-[#20B8F2]" />
              <div className="text-xl font-bold font-heading">Advanced<br/>Diagnostics</div>
              <div className="absolute right-6 top-6 px-3 py-1 bg-white/20 rounded-full text-xs font-bold backdrop-blur-sm">PRO</div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-[#20B8F2] rounded-[2rem] aspect-video col-span-2 flex items-center justify-between p-8 text-white relative overflow-hidden"
            >
              <div className="z-10">
                <Layers className="w-10 h-10 text-white/80 mb-4" />
                <div className="text-2xl font-bold font-heading">Digital Impressions</div>
              </div>
              <div className="relative z-10 w-24 h-24 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-md border border-white/20">
                <Sparkles className="w-8 h-8" />
              </div>
              
              {/* Decorative graphic */}
              <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 400 200" preserveAspectRatio="none">
                <path d="M0,100 C150,200 250,0 400,100 L400,200 L0,200 Z" fill="currentColor" />
              </svg>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
