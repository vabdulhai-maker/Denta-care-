import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';

export default function Appointment() {
  return (
    <section className="py-24 px-4 bg-white" id="appointment">
      <div className="max-w-7xl mx-auto bg-[#0077C8] rounded-[3rem] overflow-hidden">
        <div className="grid lg:grid-cols-2">
          <div className="p-12 md:p-16 lg:p-24 text-white flex flex-col justify-center">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-5xl md:text-7xl font-bold font-heading leading-[1.1] mb-6"
            >
              READY FOR A<br/>
              <span className="text-[#20B8F2]">HEALTHIER SMILE?</span>
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-lg text-white/80 font-medium mb-12 max-w-md"
            >
              Book your consultation and take the first step toward personalized dental care.
            </motion.p>

            <div className="space-y-6">
              <div>
                <div className="text-xs font-bold tracking-wider text-[#BDEFFF] uppercase mb-1">CLINIC HOURS</div>
                <div className="text-lg font-semibold">Mon – Fri: 10:00 AM – 07:00 PM<br/>Saturday: 10:00 AM – 04:00 PM<br/>Sunday: Closed</div>
              </div>
              <div>
                <div className="text-xs font-bold tracking-wider text-[#BDEFFF] uppercase mb-1">CONTACT</div>
                <div className="text-lg font-semibold">+1 (555) 123-4567<br/>hello@dentacare.com</div>
              </div>
            </div>
          </div>

          <div className="bg-white m-4 md:m-8 rounded-[2rem] p-8 md:p-12 shadow-2xl">
            <h3 className="text-3xl font-bold font-heading text-slate-900 mb-8">Book Appointment</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">First Name</label>
                  <input type="text" className="w-full px-4 py-3 bg-[#F5F7F8] border border-transparent focus:border-[#20B8F2] rounded-xl outline-none transition-colors" placeholder="John" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Last Name</label>
                  <input type="text" className="w-full px-4 py-3 bg-[#F5F7F8] border border-transparent focus:border-[#20B8F2] rounded-xl outline-none transition-colors" placeholder="Doe" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                 <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Phone</label>
                  <input type="tel" className="w-full px-4 py-3 bg-[#F5F7F8] border border-transparent focus:border-[#20B8F2] rounded-xl outline-none transition-colors" placeholder="+1 (555) 000-0000" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Email</label>
                  <input type="email" className="w-full px-4 py-3 bg-[#F5F7F8] border border-transparent focus:border-[#20B8F2] rounded-xl outline-none transition-colors" placeholder="john@example.com" />
                </div>
              </div>

               <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Treatment Interest</label>
                  <select className="w-full px-4 py-3 bg-[#F5F7F8] border border-transparent focus:border-[#20B8F2] rounded-xl outline-none transition-colors appearance-none font-medium text-slate-700">
                    <option>General Checkup</option>
                    <option>Dental Implants</option>
                    <option>Orthodontics / Aligners</option>
                    <option>Cosmetic / Whitening</option>
                    <option>Emergency</option>
                  </select>
                </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Message (Optional)</label>
                <textarea className="w-full px-4 py-3 bg-[#F5F7F8] border border-transparent focus:border-[#20B8F2] rounded-xl outline-none transition-colors min-h-[100px] resize-none" placeholder="Any specific concerns?"></textarea>
              </div>

              <button type="button" className="w-full flex items-center justify-center gap-2 px-8 py-4 text-sm font-bold text-white transition-all bg-[#FF4B12] rounded-xl hover:bg-[#e03d0a]">
                REQUEST APPOINTMENT
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
